def testing_cards(surface):
    pass
