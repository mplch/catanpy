RED = "\033[91m\033[K"
GRE = "\033[32m\033[K"
YEL = "\033[33m\033[K"
BLU = "\033[34m\033[K"
END = "\033[m\033[K"

"""
FOREST     = 'F' #darkgre
PASTURE    = 'P' #lightgre
MOUNTAINS  = 'M' #gray
CLAYPIT    = 'C' #orange        # HILLS
FIELDS     = 'E' #ellow         # dovymyslim pozdeji
DESERT     = 'D' #sandy, white  # klido bila
SEA        = 'S' #dark blu
"""

# HRACI: ABCD spis tezko, ale slo by R G Y B, resp. budou barevni
# mesto a vesnice, budiz zatim jen to H, pripadne (A) V, M -cool
# CISLA musi zustat cisly na RESOUCES yield
# mala pismenka bych nechal na suroviny (karty) NEBO OZN poli
#   // jakych poli? --> aha, asi tiles, ale to jiz vyreseno souradnicemi
# ozn poli nebude stacit, kdyby jich bylo pres 26 - souradnice?
#   // lol, mas to napsany hned tady, jen to docist.. :D
# bala pismenka rgby budiz barvy hracu na cestach
    # Rozsireni Namornici?
# cislo yieldu na barevnem pozadi dle suroviny


