map_3x3 = """

    # 0 2 4  6 8 10 2 4 8 20 2
      
      0 2 .. 4 6 .. 8 0 .. 2 4

00    ..H----H  (_8)  H----H..
      ./      \      /      \.
02    H   XX   H----H   XX   H
      .\      /      \      /.
04    ..H----H   XX   H----H..
      ./      \      /      \.
02    H   XX   H----H   XX   H
      .\      /      \      /.
04    ..H----H   XX   H----H..
      ./      \      /      \.
02    H   XX   H----H   XX   H
      .\      /      \      /.
04    ..H----H   !!   H----H..

"""

print(map_3x3)


"""
DIMENSIONs of ARRAY
1x1: 5r9c --> 5r10c

"""
